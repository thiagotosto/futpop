Dentro dessa pasta, você vai encontrar os seguintes arquivos:

* __caRtola_fetch.R__: coleta os dados da API do Cartola
* __team_data_scraper.R__: coleta dados do site da CBF
* __data_wrangling__: agrega os dados dos scouts do cartola, cria variáveis para uso em modelos preditivos agregando outras fontes.
* __rdata_2_sql.R__: transforma os dados do objeto cartola em arquivo sql.


## E como faço para rodar os códigos?

Para rodar os códigos dessa pasta, basta instalar o [R](https://www.r-project.org/). É fortemente recomendada a instalação da [IDE RStudio](https://www.rstudio.com/products/rstudio/download/).
